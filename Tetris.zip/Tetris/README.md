# STAR TETRIS

## Disclaimer
This game was created for a graduate school class project and is not for sale or commercial use.  

We make no claim to Tetris, Star Wars, or any of the copyrights or trademarks associated with them.  

## Gameplay

Run the game using your IDE

Commands:
* Rotate using A and D
* Move tetromino using arrow keys
* Spacebar = pause
* Esc = quit
